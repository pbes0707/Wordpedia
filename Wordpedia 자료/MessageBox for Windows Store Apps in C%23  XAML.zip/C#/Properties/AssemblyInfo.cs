﻿using System.Reflection;

[assembly: AssemblyTitle("MessageBox Sample")]
[assembly: AssemblyDescription("Sample showing an implementation of a MessageBox in Windows Store apps. For details see http://blog.instance-factory.com/?p=898")]
[assembly: AssemblyCompany("proccelerate GmbH")]
[assembly: AssemblyProduct("MessageBoxSample")]
[assembly: AssemblyCopyright("Copyright © 2013 by Instance Factory, a project of the proccelerate GmbH")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]